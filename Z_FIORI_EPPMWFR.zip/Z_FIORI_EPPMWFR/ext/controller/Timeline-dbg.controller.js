sap.ui.define(['sap/m/Text',
			   'sap/ui/core/mvc/ControllerExtension',
			   'sap/ui/model/Filter',
			   'sap/ui/model/FilterOperator',
			   'sap/ui/model/Sorter',
			   'sap/m/InstanceManager',
			   'sap/m/MessageBox',
			   'sap/suite/ui/commons/ProcessFlowLaneHeader',
			   'sap/suite/ui/commons/ProcessFlowNode',
			   'sap/suite/ui/commons/ProcessFlowNodeState',
			   'sap/suite/ui/commons/ProcessFlowZoomLevel',
			   'sap/ui/core/date/UI5Date',
			   'sap/ui/core/format/DateFormat'
], function (Text, ControllerExtension, Filter, FilterOperator, Sorter, InstanceManager, MessageBox, ProcessFlowLaneHeader, ProcessFlowNode,
		     ProcessFlowNodeState, ProcessFlowZoomLevel, UI5Date, DateFormat) {
	'use strict';

	return ControllerExtension.extend('eppm.workflow.report.ext.controller.Timeline', {
		// this section allows to extend lifecycle hooks or hooks provided by Fiori elements
		override: {
			routing: {
				onAfterBinding: async function (oBindingContext) {
					const oExtensionAPI = this.base.getExtensionAPI();
					const oDataModel = oExtensionAPI.getModel();
					const jsonModel = oExtensionAPI.getModel("timeline");
					const selectedStep = await oBindingContext.requestObject();
					const STEP_STATUS = {
						APPROVAL_PENDING: "0",
						CONFIG_ERROR: "5",
						MORE_INFO: "10",
						ON_HOLD: "20",
						REJECTED: "30",
						ENDORSED: "60",
						APPROVED: "70",
						CANCELLED: "90"
					};

					// const allStepsBinding = oDataModel.bindList(
					const allStepsBinding = oDataModel.bindList(
							'/ZI_PPM_WORKFLOW_STEP', undefined,
							new Sorter('LocalLastChangedAt'), 
							new Filter('WfinstMain', FilterOperator.EQ, selectedStep.PPMWorkflowUUID)
					);
					const rolesBinding = oDataModel.bindList('/ZI_PPM_ProjectRoles_DP', undefined,
							new Sorter('WorkflowSequence'), 
							new Filter('PortfolioItem', FilterOperator.EQ, selectedStep.PortfolioItem)
					);

					// const headerPath = `/ZC_PPM_DECPNT_APPR(${selectedStep.PPMWorkflowUUID})`;
					const headerPath = `/ZI_PPM_WORKFLOW_APPR(${selectedStep.PPMWorkflowUUID})`;
					const headerBinding = oDataModel.bindContext(headerPath, undefined,
																 { $select: 'InitiatedByText,LocalCreatedAt' });

					const statusFormatter = (statusCode) => {
						switch (statusCode) {
							case STEP_STATUS.APPROVED:
								return { icon: 'sap-icon://accept', state: ProcessFlowNodeState.Positive };
							case STEP_STATUS.ENDORSED:
								return { icon: 'sap-icon://accept', state: ProcessFlowNodeState.Positive };
							case STEP_STATUS.APPROVAL_PENDING:
								return { icon: 'sap-icon://inbox', state: ProcessFlowNodeState.Neutral };
							case STEP_STATUS.MORE_INFO:
								return { icon: 'sap-icon://message-information', state: ProcessFlowNodeState.Neutral };
							case STEP_STATUS.ON_HOLD:
								return { icon: 'sap-icon://pause', state: ProcessFlowNodeState.Neutral };
							case STEP_STATUS.REJECTED:
								return { icon: 'sap-icon://decline', state: ProcessFlowNodeState.Negative };
							case STEP_STATUS.CONFIG_ERROR:
								return { icon: 'sap-icon://error', state: ProcessFlowNodeState.Negative };
							case STEP_STATUS.CANCELLED:
								return { icon: 'sap-icon://cancel', state: ProcessFlowNodeState.Neutral };
							default:
								return { icon: 'sap-icon://question-mark', state: ProcessFlowNodeState.Neutral };
						}
					};

					const truncateEmail = (email) => {		//strip the domain for brevity
						if (email && email.length > 1) {
							return email.split('@')[0];
						} else {
							return email;
						}
					};

					Promise.all([allStepsBinding.requestContexts(),
						 		 rolesBinding.requestContexts(),
								 headerBinding.requestObject()])
					.then(results => {
						const allSteps = results[0].map(context => context.getObject());
						let roles = results[1].map(context => context.getObject());
						const header = results[2];

						/* filter the project roles (portfolio item WDA) so that we only have the ones
						/* that haven't yet been 'crystalised' as a step */
						const latestStep = allSteps[allSteps.length - 1];

						roles = roles.filter(role => {
							//NB we tolerate duplicate workflow sequences, as long as the position ID is different
							return role.WorkflowSequence > latestStep.WorkflowSequence ||
							       (role.WorkflowSequence === latestStep.WorkflowSequence &&
									role.PositionID !== latestStep.PositionID);
						})
						//first created an entry for the initialisation of the whole flow
						const formattedCreatedAt = DateFormat.getDateTimeInstance().format(UI5Date.getInstance(header.LocalCreatedAt));
						let nodes = [{
							isStep: false,
							role: "INITIATOR",
							title: "INITIATOR",
							icon: "sap-icon://begin",
							statusText: "Started",
							state: ProcessFlowNodeState.Positive,
							texts: [truncateEmail(header.InitiatedByText), formattedCreatedAt],
							note: ""
						}];

						//next map the steps, which have already been processed or are pending
						nodes = nodes.concat(allSteps.map(step => {
							const statusInfo = statusFormatter(step.Status);
							let aHolders = step.HolderSummary ? step.HolderSummary.split(',') : [];
							
							const oDate = UI5Date.getInstance(step.LocalLastChangedAt);
							const formattedDate = DateFormat.getDateTimeInstance().format(oDate);

							let agent, moreInfo;
							if (step.Status === STEP_STATUS.APPROVAL_PENDING) {
								if (aHolders.length === 1) {
									agent = aHolders[0];
								} else {	//can't fit all of them, just indicate how many
									agent = `${aHolders.length} assigned`;
									moreInfo = { title: "Assigned approvers", text: step.HolderSummary };
								}
							} else {
								agent = step.ProcessorEmail;
								if (step.Note && step.Note.length > 0) {
									moreInfo = { title: "Comment", text: step.Note };
								}
							}	

							return {
								isStep: true,
								stepUUID: step.StepUUID,
								role: step.GovernanceRole,
								title: `${step.WorkflowSequence} ${step.WorkflowAction}`,
								icon: statusInfo.icon,
								statusText: step.StatusText,
								state: statusInfo.state,
								texts: [ truncateEmail(agent), formattedDate],
								note: step.Note,
								moreInfo: moreInfo
							};
						}));
						const indexLastStep = nodes.length - 1;

						if ([STEP_STATUS.APPROVAL_PENDING, STEP_STATUS.ENDORSED, STEP_STATUS.APPROVED].includes(latestStep.Status)) {
							//now add the future project roles
							//NB not applicable if outcome of last step was not approved
							nodes = nodes.concat(roles.map(role => {
								return {
									isStep: false,
									role: role.DecPointGovernanceRole,
									title: `${role.WorkflowSequence} ${role.WorkflowAction}`,
									icon: "sap-icon://future",
									statusText: "",
									state: ProcessFlowNodeState.Planned,
									// agents: ""
									texts: [],
									note: ""
								};
							}));
						}

						let highlight = true;
						nodes.forEach((node, index) => {
							node.index = index;
							node.selected = index === indexLastStep; 
							if (nodes.length - index > 1) {
								//not the last lane
								node.children = ["N" + (index + 1)];
							}
							node.highlight = highlight === true;
							if (node.stepUUID === selectedStep.StepUUID) {
								//this is the selected step, next one should not be highlighted
								highlight = false;
							}
						});	

						jsonModel.setProperty('/nodes', nodes);

						const lane = new ProcessFlowLaneHeader({
							text: "{timeline>role}",
							iconSrc: "{timeline>icon}",
							position: "{timeline>index}",
							laneId: "{timeline>index}",
							zoomLevel: ProcessFlowZoomLevel.One
						});

						const node = new ProcessFlowNode({
							nodeId: "N{timeline>index}",
							laneId: "{timeline>index}",
							title:  "{timeline>title}",
							children: "{timeline>children}",
							texts:  "{timeline>texts}",
							state: "{timeline>state}",
							stateText: "{timeline>statusText}",
							highlighted: "{timeline>highlight}"
						});

						const flow = oExtensionAPI.byId("fe::CustomSubSection::Timeline--processFlow");
						flow.setWheelZoomable(false);
						InstanceManager.closeAllDialogs();

						const handlePress = oEvent => {
							const nodeIndex = oEvent.getParameters().getLaneId();
							const listBinding = oEvent.getSource().getBindingInfo("nodes").binding;
							const moreInfo = listBinding.getModel().getProperty(`/nodes/${nodeIndex}/moreInfo`);
							if (moreInfo && moreInfo.title && moreInfo.title.length > 0 &&
								moreInfo.text && moreInfo.text.length > 0) {
								MessageBox.show(moreInfo.text, { title: moreInfo.title });
							}
						}

						if (!flow.mEventRegistry || !flow.mEventRegistry.nodePress || flow.mEventRegistry.nodePress.length === 0) {		
							flow.attachNodePress(undefined, handlePress);
						}
						flow.bindAggregation("lanes", { path: "/nodes", model: "timeline", template: lane });
						flow.bindAggregation("nodes", { path: "/nodes", model: "timeline", template: node });
					})
				}
			},
		}
	});
});
