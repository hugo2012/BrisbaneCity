sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("eppm.workflow.report.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);